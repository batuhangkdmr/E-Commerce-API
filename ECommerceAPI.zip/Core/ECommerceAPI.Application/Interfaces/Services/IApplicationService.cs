﻿using ECommerceAPI.Application.DTOs.Configurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceAPI.Application.Interfaces.Services
{
    public interface IApplicationService
    {
        List<MenuDTO> GetAuthorizeDefinitionEndpoints(Type type);
    }
}
