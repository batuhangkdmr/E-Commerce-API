﻿namespace ECommerceAPI.Application.Features.Commands.AppUsers.UpdatePassword
{
    public class UpdatePasswordCommandResponse
    {
    }
}