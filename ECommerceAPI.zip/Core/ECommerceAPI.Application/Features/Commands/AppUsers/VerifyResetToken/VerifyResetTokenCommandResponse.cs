﻿namespace ECommerceAPI.Application.Features.Commands.AppUsers.VerifyResetToken
{
    public class VerifyResetTokenCommandResponse
    {
        public bool State { get; set; }
    }
}