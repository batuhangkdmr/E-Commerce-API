﻿namespace ECommerceAPI.Application.Features.Commands.AppUsers.AssignRoleToUser
{
    public class AssignRoleToUserCommandResponse
    {
    }
}