﻿namespace ECommerceAPI.Application.Features.Commands.AppUsers.PasswordReset
{
    public class PasswordResetCommandResponse
    {
    }
}