﻿namespace ECommerceAPI.Application.Features.Commands.AppRole.UpdateRole
{
    public class UpdateRoleCommandResponse
    {
        public bool Succeeded { get; set; }
    }
}