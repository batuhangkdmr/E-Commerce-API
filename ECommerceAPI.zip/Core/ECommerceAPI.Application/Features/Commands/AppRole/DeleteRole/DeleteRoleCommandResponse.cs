﻿namespace ECommerceAPI.Application.Features.Commands.AppRole.DeleteRole
{
    public class DeleteRoleCommandResponse
    {
        public bool Succeeded { get; set; }
    }
}