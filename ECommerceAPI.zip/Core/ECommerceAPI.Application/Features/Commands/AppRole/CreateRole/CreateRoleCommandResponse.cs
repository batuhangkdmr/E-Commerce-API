﻿namespace ECommerceAPI.Application.Features.Commands.AppRole.CreateRole
{
    public class CreateRoleCommandResponse
    {
        public bool Succeeded { get; set; }
    }
}