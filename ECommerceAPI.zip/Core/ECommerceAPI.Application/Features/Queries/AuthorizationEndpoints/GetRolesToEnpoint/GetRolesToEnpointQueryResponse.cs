﻿namespace ECommerceAPI.Application.Features.Queries.AuthorizationEndpoints.GetRolesToEnpoint
{
    public class GetRolesToEnpointQueryResponse
    {
        public object Roles { get; set; }
    }
}