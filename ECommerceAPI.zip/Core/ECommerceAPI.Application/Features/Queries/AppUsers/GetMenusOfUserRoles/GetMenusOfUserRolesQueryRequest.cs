﻿using MediatR;

namespace ECommerceAPI.Application.Features.Queries.AppUsers.GetMenusOfUserRoles
{
    public class GetMenusOfUserRolesQueryRequest : IRequest<GetMenusOfUserRolesQueryResponse>
    {
    }
}