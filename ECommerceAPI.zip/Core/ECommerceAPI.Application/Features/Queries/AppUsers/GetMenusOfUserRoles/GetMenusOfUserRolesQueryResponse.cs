﻿namespace ECommerceAPI.Application.Features.Queries.AppUsers.GetMenusOfUserRoles
{
    public class GetMenusOfUserRolesQueryResponse
    {
        public IList<string> Menus { get; set; }
    }
}