﻿namespace ECommerceAPI.Application.Features.Queries.AppUsers.GetRolesToUser
{
    public class GetRolesToUserQueryResponse
    {
        public IList<string> Roles { get; set; }
    }
}