﻿namespace ECommerceAPI.Application.Features.Queries.AppRole.GetAllRoles
{
    public class GetAllRolesQueryResponse
    {
        public object Roles { get; set; }
        public int TotalCount { get; set; }
    }
}