﻿namespace ECommerceAPI.Application.Features.Queries.AppRole.GetRoleById
{
    public class GetRoleByIdQueryResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}