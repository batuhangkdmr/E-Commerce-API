﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerceAPI.Application.DTOs.Comments
{
    public class CreateCommentResponseDTO
    {
        public Guid CommentId { get; set; }
    }
}
